import styles from "./AnnouncementBar.Module.css";
export default function AnnouncementBar() {
  return (
    <div className={styles.AnnouncementBar}>
      <div className={styles.scrollingText}>
        <span>Your favorite winter pieces are back </span>
        <span>limited quantities only</span>
        <span>Your favorite winter pieces are back </span>
        <span>limited quantities only</span>
        <span>Your favorite winter pieces are back </span>
        <span>limited quantities only</span>
        <span>Your favorite winter pieces are back </span>
        <span>limited quantities only</span>
        <span>Your favorite winter pieces are back </span>
        <span>limited quantities only</span>
      </div>
    </div>
  );
}
